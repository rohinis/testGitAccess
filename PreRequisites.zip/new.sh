#!/bin/sh


for i in `more userlist.txt `
do
echo
isDirPresent="/stage/"$i
echo "###########################################"
echo "stage root folder path - "$isDirPresent

#################
#Changing user  #
#################

sudo -i -u $i bash << EOF
if [ -d "$isDirPresent" ]
then
 cd /stage
 chmod 777 $i
else
  echo "/stage/"$i" not present - creating it"
  cd /stage
  mkdir $i
  chmod 777 $i
fi

cd /stage/$i

echo "Creating test data for user - "$i
mkdir LotOfFiles
cd /stage/$i/LotOfFiles
/home/BUILDS/Pre-Requisites/test/y.sh
cd ..
chmod 777 *

###################################################################
# Creating Shortcut files for job submissions                     #
###################################################################

echo "Finished creating test data for user - "$i
echo "###########################################"
EOF
echo 
done

