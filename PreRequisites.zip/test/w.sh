mkdir LotOfFiles
cd LotOfFiles
touch in.txt
j=1
for((n=1;n<=5;n++))
  do 
  echo $j
  touch $j.txt
  echo "File number $j" >> $j.txt
j=`expr $j + 1`
echo "af = $j"
 done

