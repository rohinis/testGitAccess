echo
isDirPresent="/stage/"$1
echo "###################################################################"

echo "stage root folder path - "$1sDirPresent  					

#################
#Changing user  #
#################

	if [ -d "$1sDirPresent" ]
	then
		cd /stage
		chmod 777 $1
	else
		echo "/stage/"$1" not present - creating it"  
		cd /stage
		mkdir $1
		chmod 777 $1
	fi

	cd /stage/$1

 
echo "###################################################################"
echo "          Creating test data for user - "$1
echo "###################################################################"
echo
###################################################################
# Copying test data from prereq folder to stage root area of user #
###################################################################

cp CURRENT_PATH/TestData/*.zip .
find . -name "*.zip" -exec unzip -q {} \;
cd /stage/$1
rm -rf *.zip 

echo "###################################################################"
echo "# Creating folders for upload scenarios                           #"
echo "###################################################################"

mkdir JSUploads
mkdir ProfileFiles
mkdir UnZipOps
mkdir ForHidden
mkdir B1
mkdir B2
mkdir B3
mkdir BD
mkdir BS
ln -s /stage/$1/BS /stage/$1/SCBS

cd  /stage/$1/ForHidden
mkdir .hiddenFolder
touch hiddenFile
cd ..
mkdir LotOfFiles
cd /stage/$1/LotOfFiles
 CURRENT_PATH/TestData/lotOfFile.sh
cd ..
chmod 777 *
echo
echo "###################################################################"
echo
ls
echo
echo "###################################################################"

###################################################################
# Creating Shortcut files for job submissions                     #
###################################################################
echo
echo "###################################################################"
echo "# Creating Shortcut files for job submissions                               #"
echo "###################################################################"
	cd /stage/$1/	
	mkdir ShortCutFiles
	cd  /stage/$1/ShortCutFiles/
	cp  /stage/$1/JobsModule/InputDeck/*  /stage/$1/ShortCutFiles
	ln -s /stage/$1/ShortCutFiles/Lag6elem_0000.rad /stage/$1/ShortCutFiles/SCLag6elem_0000.rad
	ln -s /stage/$1/ShortCutFiles/Lag6elem_0001.rad /stage/$1/ShortCutFiles/SCLag6elem_0001.rad
	ln -s /stage/$1/ShortCutFiles/bar.fem /stage/$1/ShortCutFiles/SCbar.fem
	ln -s /stage/$1/ShortCutFiles/RunJob.sh /stage/$1/ShortCutFiles/SCRunJob.sh
	chmod 777 -R /stage/$1/ShortCutFiles/
	echo
	echo "###################################################################"
	echo
	ls /stage/$1/ShortCutFiles/
echo
echo "###################################################################"
echo
	chmod 777 -R /stage/$1
	chown $1:root -R /stage/$1
echo "###################################################################"
echo "Finished creating test data for user - "$1  
echo "###################################################################"
echo
