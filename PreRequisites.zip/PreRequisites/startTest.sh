echo "-------------------------------------------------"
echo "Pulling latest katalon studio docker image "
echo "-------------------------------------------------"
docker pull katalonstudio/katalon

echo "-------------------------------------------------"
#echo "Cleaning old ks docker instance "
echo "-------------------------------------------------"
docker rm -f ks

echo "------------------------------"
#echo "Initiating Admin Suite "
echo "------------------------------"
docker run -t --name ks -v "$(pwd)/ExtentReports":/tmp/katalon_execute/project/ExtentReports/ -v "$(pwd)":/katalon/katalon/source katalonstudio/katalon katalon-execute.sh --retry=0 -testSuitePath="Test Suites/Sanity/AdminSuite" -browserType="Firefox (headless)" -executionProfile="ExecProfile-adminuser" -apiKey="b7e835dd-2c76-4d8a-b48e-d9057f7d54d1"

echo "------------------------------"
#echo "Initiating Sanity  Suite "
echo "------------------------------"
docker run -t --name ks -v "$(pwd)/ExtentReports":/tmp/katalon_execute/project/ExtentReports/ -v "$(pwd)":/katalon/katalon/source katalonstudio/katalon katalon-execute.sh --retry=0 -testSuiteCollectionPath="Test Suites/Sanity/SanitySuite" -apiKey="b7e835dd-2c76-4d8a-b48e-d9057f7d54d1"