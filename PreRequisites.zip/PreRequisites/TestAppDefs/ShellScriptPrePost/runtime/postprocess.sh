cp CURRENT_PATH/MultipleFilesJS.zip .
/usr/bin/unzip MultipleFilesJS.zip

cp CURRENT_PATH/MultipleFilesIconsJS.zip .
/usr/bin/unzip MultipleFilesIconsJS.zip

cp CURRENT_PATH/MultipleFolderJS.zip .
/usr/bin/unzip MultipleFolderJS.zip

cp CURRENT_PATH/MultipleFolderIconsJS.zip .
/usr/bin/unzip MultipleFolderIconsJS.zip

cp CURRENT_PATH/MultipleFolderFilesJS.zip .
/usr/bin/unzip MultipleFolderFilesJS.zip

cp CURRENT_PATH/MultipleFolderFilesIconsJS.zip .
/usr/bin/unzip MultipleFolderFilesIconsJS.zip


