touch in.txt
for ((n=1;n<=225;n++))
do
 echo "value of n "$n
  echo "$n.txt"> $n.txt
  echo "File number $n" >> $n.txt
done

