cwd=$(pwd)
source /etc/pbsworks-pa.conf
source /etc/pbs.conf


sed -i 's,CURRENT_PATH,'"$cwd"',g' filesAction.py
sed -i 's,CURRENT_PATH,'"$cwd"',g' genericactions.json
sed -i 's,CURRENT_PATH,'"$cwd"',g' $cwd/TestAppDefs/ShellScriptPrePost/runtime/postprocess.sh
sed -i 's,CURRENT_PATH,'"$cwd"',g' createTestData.sh


rm -rf $PA_HOME/data/pas/targets/localhost/repository/applications/*

cp -r $cwd/TestAppDefs/ShellScript $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/ShellScriptPrePost $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/DynamicInComplete $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/Optistruct $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/RADIOSS-SMP $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/RegularInComplete $PA_HOME/data/pas/targets/localhost/repository/applications/

cp -r $cwd/TestAppDefs/SleepJobArray $PA_HOME/data/pas/targets/localhost/repository/applications/

cp  $cwd/TestAppDefs/resourcedef $PBS_HOME/server_priv/

cd $PA_HOME/data/pas/targets/localhost/repository/

mv site-config.xml site-config-ori-xml

cp $cwd/TestAppDefs/site-config.xml $PA_HOME/data/pas/targets/localhost/repository

cd $PA_HOME/data/pas

rm -rf time_stamp.txt

cd  $PA_HOME/config/pa/
mv genericactions.json genericactions-ori-json

cp $cwd/genericactions.json  $PA_HOME/config/pa/genericactions.json

qmgr -c "create resource pas_applications_enabled"
qmgr -c "set resource pas_applications_enabled type = string_array"
qmgr -c "set resource pas_applications_enabled flag = h"



qmgr -c "create queue compute"
qmgr -c "set queue compute queue_type = Execution"
qmgr -c "set queue compute enabled = True"
qmgr -c "set queue compute started = True"


qmgr -c "create queue accessQueue"
qmgr -c "set queue accessQueue queue_type = Execution"
qmgr -c "set queue accessQueue enabled = True"
qmgr -c "set queue accessQueue started = True"

